CREATE DATABASE node_my_sql_ts;

CREATE TABLE client(
    Client_name TEXT NOT NULL,
    client_id INT(5) NOT NULL PRIMARY KEY,
    client_address VARCHAR(20),
    city VARCHAR(12),
    country VARCHAR(10)
);
DESCRIBE client;
