import { Router } from 'express'

const router = Router();
import { createClient, getClient, deleteClient, updateClient} from '../controllers/client.controller'

router.route('/client/create')
    .post(createClient);

router.route('/client/:client_id')
   .get(getClient)
   .delete(deleteClient)
   .put(updateClient);

export default router;