import { Request, Response} from 'express'

import {connect} from '../database'
import { Client} from '../interface/Client'

export async function getclient(req: Request,res: Response): Promise<Response | void> {
try{
    const conn = await connect();
    const client = await conn.query('SELECT * FROM client');
     return  res.json(client[0]);
}
catch (e) {
    console.log(e)
  }
}
export async function createClient(req: Request,res: Response){
    const newClient:Client = req.body;
    const conn =await connect();
    await conn.query('INSERT INTO client SET ?',[newClient]);
    return res.json({
        message:'client Created'
    });
}    
export async function getClient(req: Request, res: Response) {
    const client_id = req.params.client_id;
    const conn = await connect();
    const client = await conn.query('SELECT * FROM client WHERE client_id = ?', [client_id]);
    res.json(client[0]);
}
export async function deleteClient(req: Request, res: Response) {
    const client_id = req.params.client_id;
    const conn = await connect();
    await conn.query('DELETE FROM client WHERE client_id = ?', [client_id]);
    res.json({
        message: 'client deleted'
    });
}

export async function updateClient(req: Request, res: Response) {
    const client_id = req.params.client_id;
    const updateClient: Client = req.body;
    const conn = await connect();
    await conn.query('UPDATE client set ? WHERE client_id = ?', [updateClient, client_id]);
    res.json({
        message: 'client Updated'
    });
}