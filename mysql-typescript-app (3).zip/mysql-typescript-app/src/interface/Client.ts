export interface Client {

    Client_name:string;
    client_id?:string;
    client_address:string;
    city:string;
    country:string;
}